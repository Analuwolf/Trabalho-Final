var nome = prompt("digite seu nome para embarcar neste mar de histórias")
alert (`Olá ${nome}, seja muito bem vinda á bordo`)
